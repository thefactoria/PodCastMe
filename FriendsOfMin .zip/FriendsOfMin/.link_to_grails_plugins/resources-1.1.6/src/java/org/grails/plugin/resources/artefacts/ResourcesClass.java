package org.grails.plugin.resources.artefacts;

import org.codehaus.groovy.grails.commons.GrailsClass;

/**
 * @author Luke Daley (ld@ldaley.com)
 */
public interface ResourcesClass extends GrailsClass {}