package friendsofmin

class ConnexionTagLib {
	def testConnexion = { attrs, body ->
		out << "helloooo"
		
	}
	
	
	
}
