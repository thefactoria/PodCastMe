package friendsofmin

class PhotoTaggee {
	Membre owner
	Photo photo
   
}
