package friendsofmin

class Passions {
Membre adherant
Activite passion
    static constraints = {
    }
}
