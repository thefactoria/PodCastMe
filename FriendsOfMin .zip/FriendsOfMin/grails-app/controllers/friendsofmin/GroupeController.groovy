package friendsofmin


class GroupeController {

 def scaffold = Groupe
}
