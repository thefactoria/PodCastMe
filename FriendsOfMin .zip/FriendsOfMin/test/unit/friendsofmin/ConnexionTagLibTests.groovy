package friendsofmin



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.GroovyPageUnitTestMixin} for usage instructions
 */
@TestFor(ConnexionTagLib)
class ConnexionTagLibTests {

    void testSomething() {
        fail "Implement me"
    }
}
